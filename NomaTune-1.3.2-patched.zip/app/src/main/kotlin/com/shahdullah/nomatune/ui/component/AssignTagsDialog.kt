/*
 * NomaTune (2026)
 * © Shahdullah — github.com/shahdullah
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.shahdullah.nomatune.ui.component

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialogDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.floor
import com.shahdullah.nomatune.R
import com.shahdullah.nomatune.db.MusicDatabase
import com.shahdullah.nomatune.db.entities.TagEntity
import com.shahdullah.nomatune.ui.screens.library.sanitize

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AssignTagsDialog(
    database: MusicDatabase,
    playlistId: String,
    onDismiss: () -> Unit
) {
    val allTags: List<TagEntity>? by database.allTags().collectAsState(initial = null)
    val currentTags by database.playlistTags(playlistId).collectAsState(initial = emptyList())
    
    val currentTagIds = remember(currentTags) { currentTags.map { it.id }.toSet() }
    var selectedTagIds by remember(currentTagIds) { mutableStateOf(currentTagIds) }
    var showManageTagsDialog by remember { mutableStateOf(false) }
    var showAssignToPlaylistsDialog by remember { mutableStateOf(false) }
    val validTagIds = remember(allTags) { allTags?.map(TagEntity::id)?.toSet() }

    LaunchedEffect(validTagIds) {
        validTagIds?.let { selectedTagIds = selectedTagIds.sanitize(validTagIds = it) }
    }

    if (showManageTagsDialog) {
        TagsManagementDialog(
            database = database,
            onDismiss = { showManageTagsDialog = false }
        )
    }

    if (showAssignToPlaylistsDialog) {
        AssignTagsToPlaylistsDialog(
            database = database,
            initialSelectedTagIds = selectedTagIds,
            initialSelectedPlaylistIds = setOf(playlistId),
            onDismiss = { showAssignToPlaylistsDialog = false },
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            shape = AlertDialogDefaults.shape,
            color = AlertDialogDefaults.containerColor,
            tonalElevation = AlertDialogDefaults.TonalElevation
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = stringResource(R.string.assign_tags),
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (allTags.isNullOrEmpty()) {
                    Text(
                        text = stringResource(R.string.no_tags_available),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                } else {
                    FlowRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .verticalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        allTags.orEmpty().forEach { tag ->
                            TagChip(
                                tag = tag,
                                selected = tag.id in selectedTagIds,
                                onClick = {
                                    selectedTagIds = if (tag.id in selectedTagIds) {
                                        selectedTagIds - tag.id
                                    } else {
                                        selectedTagIds + tag.id
                                    }
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        TextButton(onClick = { showManageTagsDialog = true }, shapes = ButtonDefaults.shapes()) {
                            Text(stringResource(R.string.manage_tags))
                        }

                        TextButton(
                            enabled = !allTags.isNullOrEmpty(),
                            onClick = { showAssignToPlaylistsDialog = true },
                            shapes = ButtonDefaults.shapes(),
                        ) {
                            Text(stringResource(R.string.assign_tags_to_playlists))
                        }
                    }

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        TextButton(onClick = onDismiss, shapes = ButtonDefaults.shapes()) {
                            Text(stringResource(android.R.string.cancel))
                        }

                        Button(
                            onClick = {
                                database.transaction {
                                    removeAllPlaylistTags(playlistId)
                                    selectedTagIds.forEach { tagId ->
                                        addTagToPlaylist(playlistId, tagId)
                                    }
                                }
                                onDismiss()
                            },
                            shapes = ButtonDefaults.shapes(),
                        ) {
                            Text(stringResource(R.string.save))
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AssignTagsToPlaylistsDialog(
    database: MusicDatabase,
    initialSelectedTagIds: Set<String>,
    initialSelectedPlaylistIds: Set<String>,
    onDismiss: () -> Unit,
) {
    val allTags: List<TagEntity>? by database.allTags().collectAsState(initial = null)
    val playlists by database.editablePlaylistsByCreateDateAsc().collectAsState(initial = emptyList())

    var selectedTagIds by remember(initialSelectedTagIds) { mutableStateOf(initialSelectedTagIds) }
    var selectedPlaylistIds by remember(initialSelectedPlaylistIds) { mutableStateOf(initialSelectedPlaylistIds) }
    val validTagIds = remember(allTags) { allTags?.map(TagEntity::id)?.toSet() }

    LaunchedEffect(validTagIds) {
        validTagIds?.let { selectedTagIds = selectedTagIds.sanitize(validTagIds = it) }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            shape = AlertDialogDefaults.shape,
            color = AlertDialogDefaults.containerColor,
            tonalElevation = AlertDialogDefaults.TonalElevation
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = stringResource(R.string.assign_tags_to_playlists),
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (allTags.isNullOrEmpty()) {
                    Text(
                        text = stringResource(R.string.no_tags_available),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                } else {
                    FlowRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 200.dp)
                            .verticalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        allTags.orEmpty().forEach { tag ->
                            TagChip(
                                tag = tag,
                                selected = tag.id in selectedTagIds,
                                onClick = {
                                    selectedTagIds = if (tag.id in selectedTagIds) {
                                        selectedTagIds - tag.id
                                    } else {
                                        selectedTagIds + tag.id
                                    }
                                }
                            )
                        }
                    }
                }

                if (playlists.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 360.dp),
                    ) {
                        items(playlists.asReversed(), key = { it.id }) { playlist ->
                            val isSelected = playlist.id in selectedPlaylistIds
                            val cbStrokeWidthPx = with(LocalDensity.current) { floor(CheckboxDefaults.StrokeWidth.toPx()) }
                            val cbCheckmarkStroke = remember(cbStrokeWidthPx) {
                                Stroke(width = cbStrokeWidthPx, cap = StrokeCap.Round, join = StrokeJoin.Round)
                            }
                            val cbOutlineStroke = remember(cbStrokeWidthPx) { Stroke(width = cbStrokeWidthPx) }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedPlaylistIds =
                                            if (isSelected) {
                                                selectedPlaylistIds - playlist.id
                                            } else {
                                                selectedPlaylistIds + playlist.id
                                            }
                                    },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                PlaylistListItem(
                                    playlist = playlist,
                                    modifier = Modifier.weight(1f)
                                )

                                Checkbox(
                                    checked = isSelected,
                                    onCheckedChange = { checked ->
                                        selectedPlaylistIds =
                                            if (checked) {
                                                selectedPlaylistIds + playlist.id
                                            } else {
                                                selectedPlaylistIds - playlist.id
                                            }
                                    },
                                    checkmarkStroke = cbCheckmarkStroke,
                                    outlineStroke = cbOutlineStroke,
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    TextButton(onClick = onDismiss, shapes = ButtonDefaults.shapes()) {
                        Text(stringResource(android.R.string.cancel))
                    }

                    Button(
                        enabled = selectedPlaylistIds.isNotEmpty() && selectedTagIds.isNotEmpty(),
                        onClick = {
                            database.transaction {
                                addTagsToPlaylists(
                                    playlistIds = selectedPlaylistIds.toList(),
                                    tagIds = selectedTagIds.toList(),
                                )
                            }
                            onDismiss()
                        },
                        shapes = ButtonDefaults.shapes(),
                    ) {
                        Text(stringResource(R.string.save))
                    }
                }
            }
        }
    }
}
