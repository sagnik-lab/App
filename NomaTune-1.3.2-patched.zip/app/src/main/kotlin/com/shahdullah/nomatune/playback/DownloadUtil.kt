/*
 * NomaTune (2026)
 * © Shahdullah — github.com/shahdullah
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.shahdullah.nomatune.playback

import android.content.Context
import android.net.ConnectivityManager
import androidx.core.content.getSystemService
import androidx.core.net.toUri
import androidx.media3.database.DatabaseProvider
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.Cache
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadNotificationHelper
import com.shahdullah.nomatune.constants.AudioQuality
import com.shahdullah.nomatune.constants.AudioQualityKey
import com.shahdullah.nomatune.db.MusicDatabase
import com.shahdullah.nomatune.db.entities.FormatEntity
import com.shahdullah.nomatune.db.entities.SongEntity
import com.shahdullah.nomatune.di.DownloadCache
import com.shahdullah.nomatune.di.PlayerCache
import com.shahdullah.nomatune.innertube.YouTube
import com.shahdullah.nomatune.utils.AuthScopedCacheValue
import com.shahdullah.nomatune.utils.StreamClientUtils
import com.shahdullah.nomatune.utils.YTPlayerUtils
import com.shahdullah.nomatune.utils.enumPreference
import com.shahdullah.nomatune.utils.get
import com.shahdullah.nomatune.utils.isLowDataModeActive
import com.shahdullah.nomatune.utils.retryWithoutPlaybackLoginContext
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import java.time.LocalDateTime
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DownloadUtil
@Inject
constructor(
    @ApplicationContext context: Context,
    val database: MusicDatabase,
    val databaseProvider: DatabaseProvider,
    @DownloadCache val downloadCache: Cache,
    @PlayerCache val playerCache: Cache,
) {
    private val connectivityManager = context.getSystemService<ConnectivityManager>()!!
    private val audioQuality by enumPreference(context, AudioQualityKey, AudioQuality.AUTO)
    private val downloadScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val songUrlCache = ConcurrentHashMap<String, AuthScopedCacheValue>()
    private val downloadExecutor = Executors.newFixedThreadPool(DEFAULT_MAX_PARALLEL_DOWNLOADS)

    private val mediaOkHttpClient: OkHttpClient by lazy {
        OkHttpClient
            .Builder()
            .proxy(YouTube.streamOkHttpProxy)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .dispatcher(
                okhttp3.Dispatcher().apply {
                    maxRequests = MAX_DOWNLOAD_HTTP_REQUESTS
                    maxRequestsPerHost = DEFAULT_MAX_PARALLEL_DOWNLOADS
                },
            )
            .connectionPool(
                ConnectionPool(
                    MAX_IDLE_DOWNLOAD_CONNECTIONS,
                    DOWNLOAD_CONNECTION_KEEP_ALIVE_MINUTES,
                    TimeUnit.MINUTES,
                ),
            )
            .addInterceptor { chain ->
                val request = chain.request()
                val host = request.url.host
                val isYouTubeMediaHost =
                    host.endsWith("googlevideo.com") ||
                        host.endsWith("googleusercontent.com") ||
                        host.endsWith("youtube.com") ||
                        host.endsWith("youtube-nocookie.com") ||
                        host.endsWith("ytimg.com")

                if (!isYouTubeMediaHost) return@addInterceptor chain.proceed(request)

                val requestProfile = StreamClientUtils.resolveRequestProfile(request.url)
                chain.proceed(
                    StreamClientUtils.applyRequestProfile(
                        request.newBuilder(),
                        requestProfile,
                    ).build()
                )
            }.build()
    }

    val downloads = MutableStateFlow<Map<String, Download>>(emptyMap())

    private val dataSourceFactory =
        ResolvingDataSource.Factory(
            CacheDataSource
                .Factory()
                .setCache(playerCache)
                .setUpstreamDataSourceFactory(
                    OkHttpDataSource.Factory(
                        mediaOkHttpClient,
                    ),
                )
                .setCacheWriteDataSinkFactory(null),
        ) { dataSpec ->
            val mediaId = dataSpec.key ?: error("No media id")
            val length = if (dataSpec.length >= 0) dataSpec.length else 1
            if (playerCache.isCached(mediaId, dataSpec.position, length)) {
                return@Factory dataSpec
            }
            val lowDataModeActive = context.isLowDataModeActive()
            val requestedAudioQuality = resolveDownloadAudioQuality(lowDataModeActive)
            val streamCacheKey = buildSongUrlCacheKey(mediaId, requestedAudioQuality)
            val authFingerprint = YouTube.currentPlaybackAuthState().fingerprint
            songUrlCache[streamCacheKey]
                ?.takeIf {
                    it.isValidFor(
                        authFingerprint = authFingerprint,
                        minimumRemainingMs = YTPlayerUtils.STREAM_URL_EXPIRY_SAFETY_MS,
                    )
                }?.let {
                return@Factory dataSpec.withUri(it.url.toUri())
            }
            val playbackData = runBlocking(Dispatchers.IO) {
                context.retryWithoutPlaybackLoginContext {
                    YTPlayerUtils.playerResponseForDownload(
                        mediaId,
                        audioQuality = requestedAudioQuality,
                        connectivityManager = connectivityManager,
                        networkMetered = lowDataModeActive,
                    )
                }
            }.getOrThrow()
            persistPlaybackMetadata(mediaId, playbackData)

            val streamUrl = playbackData.streamUrl

            songUrlCache[streamCacheKey] =
                AuthScopedCacheValue(
                    url = streamUrl,
                    expiresAtMs = System.currentTimeMillis() + (playbackData.streamExpiresInSeconds * 1000L),
                    authFingerprint = playbackData.authFingerprint,
                )
            dataSpec.withUri(streamUrl.toUri())
        }

    val downloadNotificationHelper =
        DownloadNotificationHelper(context, ExoDownloadService.CHANNEL_ID)

    val downloadManager: DownloadManager =
        DownloadManager(
            context,
            databaseProvider,
            downloadCache,
            dataSourceFactory,
            downloadExecutor,
        ).apply {
            maxParallelDownloads = DEFAULT_MAX_PARALLEL_DOWNLOADS
            addListener(
                object : DownloadManager.Listener {
                    override fun onDownloadChanged(
                        downloadManager: DownloadManager,
                        download: Download,
                        finalException: Exception?,
                    ) {
                        downloads.update { map ->
                            map.toMutableMap().apply {
                                set(download.request.id, download)
                            }
                        }
                    }
                },
            )
        }

    init {
        downloadScope.launch {
            val result = mutableMapOf<String, Download>()
            val cursor = downloadManager.downloadIndex.getDownloads()
            while (cursor.moveToNext()) {
                result[cursor.download.request.id] = cursor.download
            }
            downloads.value = result
        }
        downloadScope.launch {
            var previousFingerprint: String? = null
            YouTube.authStateFlow
                .map { it.fingerprint }
                .distinctUntilChanged()
                .collect { fingerprint ->
                    if (previousFingerprint != null && previousFingerprint != fingerprint) {
                        songUrlCache.clear()
                    }
                    previousFingerprint = fingerprint
                }
        }
    }

    fun getDownload(songId: String): Flow<Download?> = downloads.map { it[songId] }

    private fun resolveDownloadAudioQuality(lowDataModeActive: Boolean): AudioQuality =
        if (lowDataModeActive) AudioQuality.LOW else audioQuality

    private fun buildSongUrlCacheKey(
        mediaId: String,
        requestedAudioQuality: AudioQuality,
    ): String = "$mediaId:${requestedAudioQuality.name}"

    private fun persistPlaybackMetadata(
        mediaId: String,
        playbackData: YTPlayerUtils.PlaybackData,
    ) {
        downloadScope.launch {
            runCatching {
                val format = playbackData.format
                val contentLength = format.contentLength ?: 0L
                val resolvedCodecs =
                    format.mimeType
                        .substringAfter("codecs=", "")
                        .removeSurrounding("\"")
                        .substringBefore("\"")

                database.query {
                    upsert(
                        FormatEntity(
                            id = mediaId,
                            itag = format.itag,
                            mimeType = format.mimeType.split(";")[0],
                            codecs = resolvedCodecs,
                            bitrate = format.bitrate,
                            sampleRate = format.audioSampleRate,
                            contentLength = contentLength,
                            loudnessDb = playbackData.audioConfig?.loudnessDb,
                            perceptualLoudnessDb = playbackData.audioConfig?.perceptualLoudnessDb,
                            playbackUrl = playbackData.playbackTracking?.videostatsPlaybackUrl?.baseUrl,
                        ),
                    )

                    val now = LocalDateTime.now()
                    val existing = getSongByIdBlocking(mediaId)?.song

                    val updatedSong = if (existing != null) {
                        if (existing.dateDownload == null) existing.copy(dateDownload = now) else existing
                    } else {
                        SongEntity(
                            id = mediaId,
                            title = playbackData.videoDetails?.title ?: "Unknown",
                            duration = playbackData.videoDetails?.lengthSeconds?.toIntOrNull() ?: 0,
                            thumbnailUrl = playbackData.videoDetails?.thumbnail?.thumbnails?.lastOrNull()?.url,
                            dateDownload = now,
                        )
                    }

                    upsert(updatedSong)
                }
            }
        }
    }

    companion object {
        private const val DEFAULT_MAX_PARALLEL_DOWNLOADS = 6
        private const val MAX_IDLE_DOWNLOAD_CONNECTIONS = 12
        private const val MAX_DOWNLOAD_HTTP_REQUESTS = 24
        private const val DOWNLOAD_CONNECTION_KEEP_ALIVE_MINUTES = 5L
    }
}
