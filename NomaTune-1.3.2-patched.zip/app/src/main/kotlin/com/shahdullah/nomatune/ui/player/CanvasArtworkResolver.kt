/*
 * NomaTune (2026)
 * © Shahdullah — github.com/shahdullah
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.shahdullah.nomatune.ui.player

import com.shahdullah.nomatune.canvas.NomaTuneCanvas
import com.shahdullah.nomatune.canvas.models.CanvasArtwork

internal suspend fun fetchCanvasArtworkForPlayback(
    songTitleRaw: String,
    artistNameRaw: String,
    storefront: String,
    requireVertical: Boolean,
): CanvasArtwork? {
    val songTitle = normalizeCanvasSongTitle(songTitleRaw)
    val artistName = normalizeCanvasArtistName(artistNameRaw)
    val candidates =
        linkedSetOf(
            songTitle to artistName,
            songTitleRaw to artistName,
            songTitle to artistNameRaw,
            songTitleRaw to artistNameRaw,
        ).filter { (song, artist) ->
            song.isNotBlank() && artist.isNotBlank()
        }

    return candidates.firstNotNullOfOrNull { (song, artist) ->
        NomaTuneCanvas
            .getBySongArtist(
                song = song,
                artist = artist,
                storefront = storefront,
            )?.takeIf { artwork ->
                if (requireVertical) {
                    !artwork.preferredVerticalAnimationUrl.isNullOrBlank()
                } else {
                    !artwork.preferredAnimationUrl.isNullOrBlank()
                }
            }
    }
}

private fun normalizeCanvasSongTitle(raw: String): String {
    val stripped =
        raw
            .replace(Regex("\\s*\\[[^]]*]"), "")
            .replace(
                Regex(
                    "\\s*\\((?:feat\\.?|ft\\.?|featuring|with)\\b[^)]*\\)",
                    RegexOption.IGNORE_CASE,
                ),
                "",
            )
            .replace(
                Regex(
                    "\\s*\\((?:official\\s*)?(?:music\\s*)?(?:video|mv|lyrics?|audio|visualizer|live|remaster(?:ed)?|version|edit|mix|remix)[^)]*\\)",
                    RegexOption.IGNORE_CASE,
                ),
                "",
            )
            .replace(
                Regex(
                    "\\s*-\\s*(?:official\\s*)?(?:music\\s*)?(?:video|mv|lyrics?|audio|visualizer|live|remaster(?:ed)?|version|edit|mix|remix)\\b.*$",
                    RegexOption.IGNORE_CASE,
                ),
                "",
            )
            .replace(Regex("\\s+"), " ")
            .trim()

    return stripped
        .trim('-')
        .replace(Regex("\\s+"), " ")
        .trim()
}

private fun normalizeCanvasArtistName(raw: String): String {
    val first =
        raw
            .split(
                Regex(
                    "(?:\\s*,\\s*|\\s*&\\s*|\\s+x\\s+|\\bfeat\\.?\\b|\\bft\\.?\\b|\\bfeaturing\\b|\\bwith\\b)",
                    RegexOption.IGNORE_CASE,
                ),
                limit = 2,
            ).firstOrNull().orEmpty()

    return first.replace(Regex("\\s+"), " ").trim()
}

internal suspend fun resolveCanvasArtworkForPlayback(
    mediaId: String,
    songTitleRaw: String,
    artistNameRaw: String,
    albumId: String? = null,
    albumTitleRaw: String? = null,
    storefront: String,
    requireVertical: Boolean,
    allowNetwork: Boolean,
): CanvasArtwork? {
    val cached = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        CanvasArtworkPlaybackCache.get(mediaId)
    }
    if (cached != null && (requireVertical && !cached.preferredVerticalAnimationUrl.isNullOrBlank() ||
            !requireVertical && !cached.preferredAnimationUrl.isNullOrBlank())) {
        return cached
    }

    if (!allowNetwork || mediaId.isBlank()) return null

    return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val fetched = fetchCanvasArtworkForPlayback(
            songTitleRaw = songTitleRaw,
            artistNameRaw = artistNameRaw,
            storefront = storefront,
            requireVertical = requireVertical,
        )
        if (fetched != null) {
            CanvasArtworkPlaybackCache.put(mediaId, fetched)
        }
        fetched
    }
}
