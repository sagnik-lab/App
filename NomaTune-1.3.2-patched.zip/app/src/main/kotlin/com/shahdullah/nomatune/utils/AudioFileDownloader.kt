/*
 * NomaTune (2026)
 * © Shahdullah — github.com/shahdullah
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.shahdullah.nomatune.utils

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Uri
import android.provider.DocumentsContract
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.getSystemService
import com.shahdullah.nomatune.R
import com.shahdullah.nomatune.constants.AudioFileSaveMode
import com.shahdullah.nomatune.constants.AudioFileSafTreeUriKey
import com.shahdullah.nomatune.constants.AudioQuality
import com.shahdullah.nomatune.innertube.YouTube
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream

/**
 * Downloads the raw audio file (m4a/webm/opus - whatever container YouTube serves)
 * for a given video id, saving it either to a user-specified filesystem path
 * or to a location picked through the Storage Access Framework.
 */
object AudioFileDownloader {

    const val DEFAULT_CUSTOM_LOCATION = "/storage/emulated/0/Download/NomaTune"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .proxy(YouTube.streamOkHttpProxy)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .build()
    }

    /**
     * Entry point used by menus: resolves the stream, then saves it according to
     * the user's chosen save mode.
     */
    fun downloadAsAudioFile(
        context: Context,
        videoId: String,
        title: String,
        saveMode: AudioFileSaveMode,
        customLocation: String,
        safTreeUriString: String?,
    ) {
        scope.launch {
            try {
                val connectivityManager = context.getSystemService<ConnectivityManager>()!!
                val playbackData = YTPlayerUtils.playerResponseForDownload(
                    videoId = videoId,
                    audioQuality = AudioQuality.HIGHEST,
                    connectivityManager = connectivityManager,
                ).getOrThrow()

                val extension = extensionForMimeType(playbackData.format.mimeType)
                val safeTitle = sanitizeFileName(title.ifBlank { videoId })
                val fileName = "$safeTitle.$extension"

                val request = Request.Builder()
                    .url(playbackData.streamUrl)
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw IllegalStateException("Download request failed: ${response.code}")
                    }
                    val body = response.body ?: throw IllegalStateException("Empty response body")

                    when (saveMode) {
                        AudioFileSaveMode.CUSTOM_LOCATION -> {
                            val dir = File(customLocation.ifBlank { DEFAULT_CUSTOM_LOCATION })
                            if (!dir.exists()) dir.mkdirs()
                            val outFile = File(dir, fileName)
                            FileOutputStream(outFile).use { out ->
                                body.byteStream().copyTo(out)
                            }
                        }

                        AudioFileSaveMode.SAF -> {
                            val treeUriString = safTreeUriString
                                ?: throw IllegalStateException("No SAF location selected")
                            val treeUri = Uri.parse(treeUriString)
                            val mime = mimeTypeForExtension(extension)
                            val documentId = DocumentsContract.getTreeDocumentId(treeUri)
                            val parentDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId)
                            val newDocUri = DocumentsContract.createDocument(
                                context.contentResolver,
                                parentDocUri,
                                mime,
                                fileName,
                            ) ?: throw IllegalStateException("Unable to create file in selected SAF location")
                            context.contentResolver.openOutputStream(newDocUri)?.use { out ->
                                body.byteStream().copyTo(out)
                            } ?: throw IllegalStateException("Unable to open output stream for SAF file")
                        }
                    }
                }

                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        context.getString(R.string.audio_file_download_complete, fileName),
                        Toast.LENGTH_LONG,
                    ).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        context.getString(R.string.audio_file_download_failed),
                        Toast.LENGTH_LONG,
                    ).show()
                }
            }
        }
    }

    private fun extensionForMimeType(mimeType: String): String {
        val base = mimeType.substringBefore(";").trim()
        return when {
            base.contains("mp4") -> "m4a"
            base.contains("webm") -> "webm"
            base.contains("opus") -> "opus"
            base.contains("mpeg") -> "mp3"
            else -> "m4a"
        }
    }

    private fun mimeTypeForExtension(extension: String): String = when (extension) {
        "m4a" -> "audio/mp4"
        "webm" -> "audio/webm"
        "opus" -> "audio/opus"
        "mp3" -> "audio/mpeg"
        else -> "audio/*"
    }

    private fun sanitizeFileName(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().take(150).ifBlank { "audio" }
}

/**
 * Composable helper that wires up the full "Download as Audio File" flow for any
 * song menu: handles the SAF picker when needed, persists the chosen tree
 * permission, and kicks off the actual download.
 *
 * Returns a lambda to invoke with (videoId, title) when the user taps the menu item.
 */
@Composable
fun rememberAudioFileDownloadAction(
    saveMode: com.shahdullah.nomatune.constants.AudioFileSaveMode,
    customLocation: String,
    safTreeUri: String,
    onSafTreeUriChange: (String) -> Unit,
): (String, String) -> Unit {
    val context = LocalContext.current
    var pendingDownload by remember { mutableStateOf<Pair<String, String>?>(null) }

    val safPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            } catch (_: SecurityException) {
            }
            onSafTreeUriChange(uri.toString())
            pendingDownload?.let { (videoId, title) ->
                AudioFileDownloader.downloadAsAudioFile(
                    context = context,
                    videoId = videoId,
                    title = title,
                    saveMode = com.shahdullah.nomatune.constants.AudioFileSaveMode.SAF,
                    customLocation = customLocation,
                    safTreeUriString = uri.toString(),
                )
            }
        }
        pendingDownload = null
    }

    return { videoId: String, title: String ->
        when (saveMode) {
            com.shahdullah.nomatune.constants.AudioFileSaveMode.CUSTOM_LOCATION -> {
                Toast.makeText(context, context.getString(R.string.audio_file_download_started), Toast.LENGTH_SHORT).show()
                AudioFileDownloader.downloadAsAudioFile(
                    context = context,
                    videoId = videoId,
                    title = title,
                    saveMode = saveMode,
                    customLocation = customLocation,
                    safTreeUriString = null,
                )
            }
            com.shahdullah.nomatune.constants.AudioFileSaveMode.SAF -> {
                if (safTreeUri.isNotBlank()) {
                    Toast.makeText(context, context.getString(R.string.audio_file_download_started), Toast.LENGTH_SHORT).show()
                    AudioFileDownloader.downloadAsAudioFile(
                        context = context,
                        videoId = videoId,
                        title = title,
                        saveMode = saveMode,
                        customLocation = customLocation,
                        safTreeUriString = safTreeUri,
                    )
                } else {
                    pendingDownload = videoId to title
                    safPickerLauncher.launch(null)
                }
            }
        }
    }
}
