/*
 * NomaTune (2026)
 * © Shahdullah — github.com/shahdullah
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.shahdullah.nomatune.lyrics

import android.content.Context
import android.util.Log
import android.util.LruCache
import com.shahdullah.nomatune.utils.GlobalLog
import com.shahdullah.nomatune.constants.LyricsProviderOrderKey
import com.shahdullah.nomatune.constants.PreferredLyricsProvider
import com.shahdullah.nomatune.constants.deserializeLyricsProviderOrder
import com.shahdullah.nomatune.db.entities.LyricsEntity.Companion.LYRICS_NOT_FOUND
import com.shahdullah.nomatune.lyrics.LyricsUtils.isLineSyncedLrc
import com.shahdullah.nomatune.lyrics.LyricsUtils.isTtml
import com.shahdullah.nomatune.models.MediaMetadata
import com.shahdullah.nomatune.utils.dataStore
import com.shahdullah.nomatune.utils.reportException
import com.shahdullah.nomatune.utils.NetworkConnectivityObserver
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.async
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.supervisorScope
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.selects.select
import javax.inject.Inject

class LyricsHelper
@Inject
constructor(
    @ApplicationContext private val context: Context,
    private val networkConnectivity: NetworkConnectivityObserver,
) {
    private val baseProviders =
        listOf(
            BetterLyricsProvider,
            LrcLibLyricsProvider,
            KuGouLyricsProvider,
            SimpMusicLyricsProvider,
            UnisonLyricsProvider,
            PaxsenixAppleMusicLyricsProvider,
            PaxsenixNeteaseLyricsProvider,
            PaxsenixSpotifyLyricsProvider,
            PaxsenixMusixmatchLyricsProvider,
            PaxsenixYouTubeLyricsProvider,
            YouTubeSubtitleLyricsProvider,
            YouTubeLyricsProvider,
        )

    private val cache = LruCache<String, List<LyricsResult>>(MAX_CACHE_SIZE)
    private val singleLyricsCache = LruCache<String, String>(MAX_CACHE_SIZE)
    private val inFlight = ConcurrentHashMap<String, kotlinx.coroutines.Deferred<List<LyricsResult>>>()
    private var currentLyricsJob: Job? = null

    suspend fun getLyrics(mediaMetadata: MediaMetadata, preferredProviderOnly: Boolean = false): String {
        val cacheKey = mediaMetadata.lyricsCacheKey
        singleLyricsCache.get(cacheKey)?.let { lyrics ->
            GlobalLog.append(Log.DEBUG, "LyricsHelper", "Found lyrics in cache for ${mediaMetadata.title}")
            return lyrics
        }

        val cached = cache.get(cacheKey)?.firstOrNull()
        if (cached != null) {
            GlobalLog.append(Log.DEBUG, "LyricsHelper", "Found lyrics in cache for ${mediaMetadata.title}")
            return cached.lyrics
        }
        
        GlobalLog.append(Log.DEBUG, "LyricsHelper", "Fetching lyrics for ${mediaMetadata.title} (Artist: ${mediaMetadata.artists.joinToString { it.name }}, Album: ${mediaMetadata.album?.title})")

        val isNetworkAvailable = try {
            networkConnectivity.isCurrentlyConnected()
        } catch (e: Exception) {
            true
        }
        
        if (!isNetworkAvailable) {
            GlobalLog.append(Log.WARN, "LyricsHelper", "Network unavailable, aborting lyrics fetch")
            return LYRICS_NOT_FOUND
        }

        val ordered = orderedProviders().filter { it.isEnabled(context) }
        val providers = if (preferredProviderOnly) ordered.take(1) else ordered
        val lyrics = fetchPriorityLyrics(providers, mediaMetadata)
        if (isMeaningfulLyrics(lyrics)) {
            singleLyricsCache.put(cacheKey, lyrics)
        }

        return lyrics
    }

    suspend fun getAllLyrics(
        mediaId: String,
        songTitle: String,
        songArtists: String,
        songAlbum: String?,
        duration: Int,
        callback: (LyricsResult) -> Unit,
    ) {
        currentLyricsJob?.cancel()

        val cacheKey = lyricsCacheKey(songTitle, songArtists)
        cache.get(cacheKey)?.let { results ->
            results.forEach {
                callback(it)
            }
            return
        }

        val isNetworkAvailable = try {
            networkConnectivity.isCurrentlyConnected()
        } catch (e: Exception) {
            true
        }
        
        if (!isNetworkAvailable) {
            return
        }

        val allResult = mutableListOf<LyricsResult>()
        val providers = orderedProviders()
        currentLyricsJob = CoroutineScope(SupervisorJob() + Dispatchers.IO).async {
            providers.forEach { provider ->
                if (!provider.isEnabled(context)) return@forEach

                try {
                    provider.getAllLyrics(mediaId, songTitle, songArtists, songAlbum, duration) lyricsCallback@{ lyrics ->
                        if (!isMeaningfulLyrics(lyrics)) return@lyricsCallback
                        val result = LyricsResult(provider.name, lyrics)
                        allResult += result
                        callback(result)
                    }
                } catch (e: Exception) {
                    reportException(e)
                }
            }
            cache.put(cacheKey, allResult)
        }

        currentLyricsJob?.join()
    }

    private suspend fun fetchPriorityLyrics(
        providers: List<LyricsProvider>,
        mediaMetadata: MediaMetadata,
    ): String {
        if (providers.isEmpty()) return LYRICS_NOT_FOUND

        val artist = mediaMetadata.artists.joinToString { it.name }
        val firstResult = fetchProviderLyrics(providers.first(), mediaMetadata, artist)

        if (firstResult != null) {
            // If priority provider returned synced lyrics, use them immediately
            if (isLineSyncedLrc(firstResult) || isTtml(firstResult)) {
                return firstResult
            }
            // Priority provider returned plain text — keep searching remaining providers
            // for synced lyrics; fall back to plain text if none found
            val syncedResult = fetchFirstSyncedLyrics(providers.drop(1), mediaMetadata, artist)
            return syncedResult ?: firstResult
        }

        return fetchFirstMeaningfulLyrics(providers.drop(1), mediaMetadata, artist)
    }

    /**
     * Runs all providers in parallel and returns the first SYNCED result (LRC/TTML).
     * Plain-text results are ignored. Returns null if no synced lyrics found.
     */
    private suspend fun fetchFirstSyncedLyrics(
        providers: List<LyricsProvider>,
        mediaMetadata: MediaMetadata,
        artist: String,
    ): String? = supervisorScope {
        val requests = providers.map { provider ->
            async(Dispatchers.IO) { fetchProviderLyrics(provider, mediaMetadata, artist) }
        }
        if (requests.isEmpty()) return@supervisorScope null

        val pending = requests.toMutableSet()
        while (pending.isNotEmpty()) {
            val (request, lyrics) = select<Pair<Deferred<String?>, String?>> {
                pending.forEach { deferred ->
                    deferred.onAwait { result -> deferred to result }
                }
            }
            pending.remove(request)
            if (lyrics != null && (isLineSyncedLrc(lyrics) || isTtml(lyrics))) {
                pending.forEach { it.cancel() }
                return@supervisorScope lyrics
            }
        }
        null
    }

    /**
     * Runs all providers in parallel. Prefers SYNCED lyrics (LRC/TTML) over plain text.
     * If synced lyrics are found, returns them immediately. Otherwise returns first plain text.
     */
    private suspend fun fetchFirstMeaningfulLyrics(
        providers: List<LyricsProvider>,
        mediaMetadata: MediaMetadata,
        artist: String,
    ): String = supervisorScope {
        val requests =
            providers
                .map { provider ->
                    async(Dispatchers.IO) {
                        fetchProviderLyrics(provider, mediaMetadata, artist)
                    }
                }

        if (requests.isEmpty()) return@supervisorScope LYRICS_NOT_FOUND

        var plainTextFallback: String? = null
        val pending = requests.toMutableSet()
        while (pending.isNotEmpty()) {
            val (request, lyrics) = select<Pair<Deferred<String?>, String?>> {
                pending.forEach { deferred ->
                    deferred.onAwait { result -> deferred to result }
                }
            }
            pending.remove(request)
            if (lyrics != null) {
                if (isLineSyncedLrc(lyrics) || isTtml(lyrics)) {
                    // Synced lyrics found — cancel the rest and use them
                    pending.forEach { it.cancel() }
                    return@supervisorScope lyrics
                }
                // Plain text — keep as fallback and keep looking for synced
                if (plainTextFallback == null) plainTextFallback = lyrics
            }
        }

        plainTextFallback ?: LYRICS_NOT_FOUND
    }

    private suspend fun fetchProviderLyrics(
        provider: LyricsProvider,
        mediaMetadata: MediaMetadata,
        artist: String,
    ): String? {
        return try {
            provider.getLyrics(
                mediaMetadata.id,
                mediaMetadata.title,
                artist,
                mediaMetadata.album?.title,
                mediaMetadata.duration,
            ).fold(
                onSuccess = { lyrics ->
                    lyrics.takeIf(::isMeaningfulLyrics)
                },
                onFailure = {
                    reportException(it)
                    null
                },
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            reportException(e)
            null
        }
    }

    private suspend fun orderedProviders(): List<LyricsProvider> {
        val orderStr = context.dataStore.data.first()[LyricsProviderOrderKey]
        val orderedEnums = deserializeLyricsProviderOrder(orderStr)
        val providerMap: Map<PreferredLyricsProvider, LyricsProvider> = mapOf(
            PreferredLyricsProvider.LRCLIB to LrcLibLyricsProvider,
            PreferredLyricsProvider.KUGOU to KuGouLyricsProvider,
            PreferredLyricsProvider.BETTER_LYRICS to BetterLyricsProvider,
            PreferredLyricsProvider.SIMPMUSIC to SimpMusicLyricsProvider,
            PreferredLyricsProvider.PAXSENIX_APPLE_MUSIC to PaxsenixAppleMusicLyricsProvider,
            PreferredLyricsProvider.PAXSENIX_NETEASE to PaxsenixNeteaseLyricsProvider,
            PreferredLyricsProvider.PAXSENIX_SPOTIFY to PaxsenixSpotifyLyricsProvider,
            PreferredLyricsProvider.PAXSENIX_MUSIXMATCH to PaxsenixMusixmatchLyricsProvider,
            PreferredLyricsProvider.PAXSENIX_YOUTUBE to PaxsenixYouTubeLyricsProvider,
            PreferredLyricsProvider.UNISON to UnisonLyricsProvider,
        )
        val userOrdered = orderedEnums.mapNotNull { providerMap[it] }
        val rest = baseProviders.filterNot { it in userOrdered }
        return userOrdered + rest
    }

    private fun isMeaningfulLyrics(lyrics: String): Boolean {
        val normalized =
            lyrics
                .replace("\uFEFF", "")
                .replace(INVISIBLE_CHARS_REGEX, "")
                .trim { it.isWhitespace() || it == '\u00A0' }

        if (normalized.isEmpty()) return false
        if (normalized == LYRICS_NOT_FOUND) return false

        // Accept timestamp-only LRC (instrumental tracks)
        if (normalized.lines().count { TIMESTAMP_REGEX.containsMatchIn(it) } >= 2) return true

        val remaining =
            TIMESTAMP_REGEX
                .replace(normalized, "")
                .replace(INVISIBLE_CHARS_REGEX, "")
                .trim { it.isWhitespace() || it == '\u00A0' }

        return remaining.any { !it.isWhitespace() && it != '\u00A0' }
    }

    fun cancelCurrentLyricsJob() {
        currentLyricsJob?.cancel()
        currentLyricsJob = null
    }

    fun clearCache() {
        cache.evictAll()
        singleLyricsCache.evictAll()
    }

    private val MediaMetadata.lyricsCacheKey: String
        get() = lyricsCacheKey(
            title = title,
            artists = artists.joinToString { it.name },
            album = album?.title,
        )

    private fun lyricsCacheKey(
        title: String,
        artists: String,
        album: String? = null,
    ): String = "${artists.trim().lowercase()}::${title.trim().lowercase()}" +
        (album?.let { "::${it.trim().lowercase()}" } ?: "")

    companion object {
        private const val MAX_CACHE_SIZE = 16
        private val TIMESTAMP_REGEX = Regex("""\[[0-9]{1,2}:[0-9]{2}(?:\.[0-9]{1,3})?]""")
        private val INVISIBLE_CHARS_REGEX = Regex("""[\u200B\u200C\u200D\u2060\u00AD]""")
    }
}

data class LyricsResult(
    val providerName: String,
    val lyrics: String,
)
